from cumm.constants import TENSORVIEW_INCLUDE_PATH

if __name__ == "__main__":
    print(str(TENSORVIEW_INCLUDE_PATH))