#pragma once 
#include "cuda/device_ops.h"